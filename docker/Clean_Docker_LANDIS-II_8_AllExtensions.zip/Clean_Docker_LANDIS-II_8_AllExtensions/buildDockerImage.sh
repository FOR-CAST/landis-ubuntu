#!/bin/bash

# Build the Docker image with the specified tag
docker build -t landis-ii_v7_linux .